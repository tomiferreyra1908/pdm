/*
 * API_uart.c
 *
 *  Created on: Sep 25, 2025
 *      Author: tomas1908
 */

#include "API_uart.h"
extern UART_HandleTypeDef huart1;

bool uartInit(){
	if(HAL_UART_Init(&huart1)==HAL_OK){
		return true;
	}
	else{
		return false;
	}
}

void uartSendString(uint8_t * pstring){
	uint32_t i=0;
	char end='a';
	do{
		end=pstring[i];
		i++;
	}while(end!='\0');

	HAL_UART_Transmit(&huart1, pstring, sizeof(&pstring), HAL_MAX_DELAY);
}


void uartSendStringSize(uint8_t * pstring, uint16_t size){
	HAL_UART_Transmit(&huart1, pstring, size, HAL_MAX_DELAY);
}

void uartReceiveStringSize(uint8_t * pstring, uint16_t size){
	HAL_UART_Receive(&huart1, pstring, size, HAL_MAX_DELAY);
}
