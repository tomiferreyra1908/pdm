/*
 * API_delay.c
 *
 *  Created on: Sep 7, 2025
 *      Author: tomas1908
 */

#include "API_delay.h"
#include "stm32f4xx_hal.h"

/*Funcion para inicializar el delay*/
void delayInit( delay_t * delay, tick_t duration ){
	delay->running=false;								//asignaciones
	delay->duration=duration;
}

/*Funcion para chechear si se termino el tiempo de delay*/
bool_t delayRead( delay_t * delay ){
	if(!delay->running){
		delay->startTime= HAL_GetTick();
		delay->running=true;
	}

	if(HAL_GetTick()-delay->startTime >= delay->duration){
		delay->running=false;
	}

	return (delay->running);
}

/*Funcion para modificar el tiempo de delay*/
void delayWrite( delay_t * delay, tick_t duration ){
	delay->duration=duration;
}

/*Funcion que devuelve una copia del parametro running*/
bool_t delayIsRunning(delay_t * delay){
	return (delay->running);
}
